# Secure Multi-Site Network Lab

A portfolio-ready enterprise networking lab inspired by multi-site public-sector IT environments such as PMIS, HMIS, e-Khidmat service centers, and centralized Education CCTV monitoring.

> **Important:** This repository uses only fictional lab names, private IP addressing, dummy credentials, and simulated configurations. It does **not** contain any real PITB production IP addresses, passwords, VPN secrets, CCTV URLs, firewall exports, or confidential internal diagrams.

## Project Goals

This lab demonstrates practical skills in:

- Multi-site LAN/WAN design
- VLAN segmentation
- Inter-VLAN routing
- Firewall security policies
- IPsec Site-to-Site VPN
- Windows Server / Active Directory
- DNS and DHCP
- Network monitoring
- CCTV / NVR network isolation
- Centralized logging
- Connectivity and security testing
- Technical documentation

## Lab Sites

1. **Central/Core Site**
   - Core Layer-3 Switch
   - Firewall / VPN Gateway
   - Windows Server
   - Monitoring Server
   - Syslog Server
   - PMIS Demo Application
   - HMIS Demo Application

2. **e-Khidmat Branch**
   - Branch Firewall
   - Access Switch
   - User PCs
   - Printers
   - Site-to-Site VPN

3. **Education CCTV Site**
   - NVR
   - IP Cameras
   - CCTV VLAN
   - Restricted communication to central monitoring

4. **Remote Office**
   - Branch Router/Firewall
   - LAN Users
   - VPN connectivity to the Central Site

## High-Level Topology

```text
                          INTERNET
                             |
                      [ CENTRAL FIREWALL ]
                       Firewall + IPsec VPN
                             |
                         [ CORE L3 ]
                             |
        +--------------------+--------------------+
        |                    |                    |
    PMIS VLAN            HMIS VLAN           SERVER VLAN
   10.10.10.0/24        10.10.20.0/24       10.10.60.0/24
        |                    |                    |
    PMIS Users           HMIS Users        AD/DNS/Monitoring
                                                  |
                                            CCTV Monitoring
                                                  |
                                    =========================
                                    Site-to-Site IPsec VPN
                                    =========================
                                       |               |
                                e-Khidmat Site     Remote Site
                                       |
                                 Education CCTV
```

## VLAN Plan

| VLAN | Name | Subnet | Purpose |
|---|---|---|---|
| 10 | PMIS | 10.10.10.0/24 | PMIS users |
| 20 | HMIS | 10.10.20.0/24 | HMIS users |
| 30 | IT-MGMT | 10.10.30.0/24 | IT administration |
| 40 | CCTV | 10.10.40.0/24 | Cameras and NVRs |
| 50 | EKHIDMAT | 10.10.50.0/24 | e-Khidmat users |
| 60 | SERVERS | 10.10.60.0/24 | AD, DNS, apps, monitoring |
| 70 | PRINTER-IOT | 10.10.70.0/24 | Printers and IoT |
| 80 | GUEST | 10.10.80.0/24 | Internet-only guest users |

## Example Server IPs

| System | Address |
|---|---|
| Domain Controller / DNS | 10.10.60.10 |
| Monitoring Server | 10.10.60.20 |
| PMIS Demo Server | 10.10.60.30 |
| HMIS Demo Server | 10.10.60.40 |
| Syslog Server | 10.10.60.50 |
| CCTV Monitoring Server | 10.10.60.60 |

## Security Design

- PMIS users can access only approved PMIS services.
- HMIS users can access only approved HMIS services.
- Guest VLAN cannot access internal networks.
- CCTV devices cannot initiate access to user VLANs.
- IT Management VLAN can administer approved network devices.
- Branch sites reach central resources through IPsec VPN.
- Unnecessary inter-VLAN traffic is denied.
- Logging is enabled for important firewall deny/allow rules.

## Repository Structure

```text
secure-multisite-network-lab/
├── README.md
├── .gitignore
├── LICENSE
├── diagrams/
├── configurations/
├── documentation/
├── screenshots/
└── testing/
```

## Suggested Tools

- EVE-NG or GNS3
- Cisco IOS / IOSv
- pfSense / OPNsense or lab firewall
- VMware Workstation / VirtualBox
- Windows Server 2022 Evaluation
- Ubuntu Server
- Zabbix or LibreNMS
- Syslog
- VLC / test RTSP source for CCTV simulation

## Recommended GitHub Screenshots

Add screenshots of:

- Network topology
- VLAN interfaces
- Routing table
- Firewall rules
- IPsec VPN status
- Active Directory users/OUs
- DNS and DHCP
- Monitoring dashboard
- CCTV/NVR reachability
- Security test results

## Resume Value

This project demonstrates hands-on knowledge of:

**Network Administration • Routing & Switching • VLANs • Firewall • VPN • Windows Server • Active Directory • DNS • DHCP • Monitoring • CCTV/IP Surveillance • Troubleshooting**

## Disclaimer

This is a personal laboratory and portfolio project. All configurations, addresses, organization names, users, and systems are fictional or simulated for training purposes.
