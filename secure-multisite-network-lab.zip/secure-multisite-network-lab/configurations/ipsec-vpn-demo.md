# Site-to-Site IPsec VPN - Lab Template

> Never commit real PSKs, certificates, private keys, or production public IPs.

## Central Site

- Local network: `10.10.0.0/16`
- Remote network: `10.20.0.0/16`
- IKE: IKEv2
- Authentication: Dummy lab PSK stored outside Git
- Encryption: AES-256
- Integrity: SHA-256
- DH Group: 14 or stronger if supported
- PFS: Enabled
- Tunnel monitoring: Enabled

## e-Khidmat Branch

- Local network: `10.20.0.0/16`
- Remote network: `10.10.0.0/16`

## Validation

1. Verify Phase 1 established.
2. Verify Phase 2 established.
3. Ping allowed central test host.
4. Test application port.
5. Confirm denied access to non-approved VLANs.
6. Check VPN logs.
