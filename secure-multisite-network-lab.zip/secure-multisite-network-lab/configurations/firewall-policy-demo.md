# Firewall Policy Examples

These are policy-design examples, not production rules.

| Rule | Source | Destination | Service | Action | Log |
|---|---|---|---|---|---|
| 1 | IT-MGMT | Network Devices | HTTPS/SSH/SNMP | Allow | Yes |
| 2 | PMIS VLAN | PMIS Demo Server | HTTPS | Allow | Yes |
| 3 | HMIS VLAN | HMIS Demo Server | HTTPS | Allow | Yes |
| 4 | CCTV VLAN | CCTV Monitoring Server | ICMP/HTTPS/RTSP-Lab | Allow | Yes |
| 5 | CCTV VLAN | User VLANs | Any | Deny | Yes |
| 6 | Guest VLAN | Internal RFC1918 | Any | Deny | Yes |
| 7 | Guest VLAN | Internet | HTTP/HTTPS/DNS | Allow | Yes |
| 8 | Branch VPN | Approved Central Services | Required Only | Allow | Yes |
| 9 | Any | Any | Any | Deny | Yes |

## Design Principles

- Default deny between security zones.
- Permit only required application ports.
- Keep CCTV separated from user networks.
- Restrict management access to IT-MGMT.
- Log denied traffic useful for troubleshooting.
- Do not expose management interfaces directly to the internet.
