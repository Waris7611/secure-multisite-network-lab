# DHCP Scope Examples

| VLAN | Scope | Gateway | DNS |
|---|---|---|---|
| PMIS | 10.10.10.100-200 | 10.10.10.1 | 10.10.60.10 |
| HMIS | 10.10.20.100-200 | 10.10.20.1 | 10.10.60.10 |
| IT-MGMT | 10.10.30.100-150 | 10.10.30.1 | 10.10.60.10 |
| CCTV | Static/Reserved preferred | 10.10.40.1 | 10.10.60.10 |
| e-Khidmat | 10.10.50.100-200 | 10.10.50.1 | 10.10.60.10 |
| Guest | 10.10.80.100-230 | 10.10.80.1 | Public/Lab DNS |

For CCTV/NVR devices, static addresses or DHCP reservations are easier to monitor consistently.
