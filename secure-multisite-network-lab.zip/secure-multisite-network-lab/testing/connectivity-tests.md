# Connectivity Tests

| Test | Source | Destination | Expected |
|---|---|---|---|
| 1 | PMIS PC | PMIS Server | Pass |
| 2 | HMIS PC | HMIS Server | Pass |
| 3 | IT-MGMT PC | Core Switch | Pass |
| 4 | Guest PC | Internet | Pass |
| 5 | Guest PC | Server VLAN | Block |
| 6 | CCTV NVR | Monitoring Server | Pass |
| 7 | CCTV Device | PMIS PC | Block |
| 8 | e-Khidmat Branch | Approved Central Server | Pass |

## Commands

```bash
ping 10.10.60.30
tracert 10.10.60.30
nslookup lab.local
```

On Linux:

```bash
ping -c 4 10.10.60.30
traceroute 10.10.60.30
```
