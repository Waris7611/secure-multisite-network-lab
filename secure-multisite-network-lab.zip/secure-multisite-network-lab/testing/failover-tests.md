# Failure and Recovery Tests

## Device Down Test

1. Start monitoring.
2. Shut down a lab switch interface or test VM.
3. Confirm monitoring detects the outage.
4. Record detection time.
5. Restore the device.
6. Confirm recovery status.

## VPN Failure Test

1. Confirm tunnel is active.
2. Disable branch WAN interface.
3. Confirm VPN becomes unavailable.
4. Restore WAN.
5. Confirm tunnel re-establishes.

## CCTV Offline Test

1. Confirm NVR/test device is reachable.
2. Power off or disconnect the lab device.
3. Confirm monitoring alert.
4. Restore device.
5. Confirm alert clears.

Use only simulated lab devices.
