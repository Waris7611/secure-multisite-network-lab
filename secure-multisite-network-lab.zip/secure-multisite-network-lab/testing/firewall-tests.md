# Firewall Security Tests

## Test 1 - Guest Isolation

**Source:** Guest VLAN  
**Destination:** 10.10.60.10  
**Expected:** Blocked

## Test 2 - PMIS Application Access

**Source:** PMIS VLAN  
**Destination:** PMIS Demo Server  
**Service:** HTTPS  
**Expected:** Allowed

## Test 3 - PMIS to HMIS

**Source:** PMIS VLAN  
**Destination:** HMIS VLAN  
**Expected:** Blocked unless explicitly required

## Test 4 - CCTV Isolation

**Source:** CCTV VLAN  
**Destination:** PMIS/HMIS user VLANs  
**Expected:** Blocked

## Test 5 - IT Management

**Source:** IT-MGMT VLAN  
**Destination:** Network device management IP  
**Expected:** Allowed on approved management protocols

Capture sanitized screenshots of firewall logs for the portfolio.
