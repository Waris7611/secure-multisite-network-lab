# VPN Tests

## Checklist

- [ ] IKE Phase 1 established
- [ ] IPsec Phase 2 established
- [ ] Central route to branch exists
- [ ] Branch route to central exists
- [ ] Approved application traffic passes
- [ ] Unauthorized VLAN access is blocked
- [ ] Tunnel reconnects after simulated outage
- [ ] VPN events visible in logs

## Example Test

From a branch lab PC:

```bash
ping 10.10.60.20
```

Then verify that access to a non-approved central subnet is denied by policy.
