# Final Project Checklist

## Network
- [ ] VLANs created
- [ ] Gateways configured
- [ ] Trunks configured
- [ ] Access ports assigned
- [ ] Routing works

## Security
- [ ] Default-deny design
- [ ] PMIS/HMIS separation
- [ ] Guest isolation
- [ ] CCTV isolation
- [ ] IT management restrictions

## VPN
- [ ] Site-to-site VPN working
- [ ] Routes verified
- [ ] Unauthorized access blocked

## Windows Server
- [ ] AD installed
- [ ] DNS working
- [ ] DHCP scopes created
- [ ] OUs created
- [ ] Test clients joined

## Monitoring
- [ ] Core device monitored
- [ ] Server monitored
- [ ] VPN monitored
- [ ] CCTV/NVR monitored
- [ ] Offline alert tested

## GitHub
- [ ] No real credentials
- [ ] No production IPs
- [ ] No VPN secrets
- [ ] No real CCTV URLs
- [ ] No confidential screenshots
- [ ] README complete
