# Network Topology

```mermaid
flowchart TB
    Internet((Internet))
    FW[Central Firewall / VPN Gateway]
    Core[Core Layer-3 Switch]

    Internet --> FW
    FW --> Core

    Core --> PMIS[PMIS VLAN 10]
    Core --> HMIS[HMIS VLAN 20]
    Core --> MGMT[IT Management VLAN 30]
    Core --> CCTV[CCTV VLAN 40]
    Core --> SERVERS[Server VLAN 60]
    Core --> GUEST[Guest VLAN 80]

    SERVERS --> AD[AD / DNS / DHCP]
    SERVERS --> NMS[Monitoring Server]
    SERVERS --> SYSLOG[Syslog Server]
    SERVERS --> PMISSRV[PMIS Demo Server]
    SERVERS --> HMISSRV[HMIS Demo Server]

    FW --> VPN1[IPsec VPN - e-Khidmat Branch]
    FW --> VPN2[IPsec VPN - Remote Office]
    FW --> VPN3[IPsec VPN - Education CCTV Site]

    VPN1 --> EK[e-Khidmat Users]
    VPN2 --> RO[Remote Office LAN]
    VPN3 --> NVR[NVR + IP Cameras]
```

## Notes

- All IP addresses are private lab addresses.
- The firewall is the security boundary between internet, branch VPNs, and internal networks.
- CCTV is isolated from normal user networks.
- Guest users are restricted to internet-only access.
