# VPN Topology

```mermaid
flowchart LR
    C[Central Firewall<br/>10.10.30.1]
    E[e-Khidmat Branch Firewall<br/>10.20.0.1]
    R[Remote Office Firewall<br/>10.30.0.1]
    V[Education CCTV Site Firewall<br/>10.40.0.1]

    C <-->|IPsec Site-to-Site| E
    C <-->|IPsec Site-to-Site| R
    C <-->|IPsec Site-to-Site| V
```

## Example Protected Networks

| Site | Lab Network |
|---|---|
| Central | 10.10.0.0/16 |
| e-Khidmat | 10.20.0.0/16 |
| Remote Office | 10.30.0.0/16 |
| Education CCTV | 10.40.0.0/16 |

Never publish real VPN public IPs, PSKs, certificates, or production tunnel names.
