# Windows Server Lab

## Proposed Server

- Windows Server 2022 Evaluation
- Hostname: `LAB-DC01`
- IP: `10.10.60.10/24`
- Gateway: `10.10.60.1`
- Lab domain: `lab.local`

## Roles

- Active Directory Domain Services
- DNS
- DHCP
- Group Policy Management

## Example OUs

```text
LAB.LOCAL
├── PMIS-Users
├── HMIS-Users
├── EKhidmat-Users
├── IT-Admins
├── Workstations
└── Servers
```

## Example GPO Ideas

- Password and account lockout policy
- Disable local guest account
- Screen-lock timeout
- Windows Defender configuration
- Windows Update policy
- Restrict removable storage for selected lab PCs
- Map approved shared folders

Do not publish real organization usernames, domain names, passwords, or GPO exports.
