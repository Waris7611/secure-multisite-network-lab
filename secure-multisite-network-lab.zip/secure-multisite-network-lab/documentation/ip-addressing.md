# IP Addressing Plan

## Central Site

| VLAN | Network | Gateway | Description |
|---|---|---|---|
| 10 | 10.10.10.0/24 | 10.10.10.1 | PMIS |
| 20 | 10.10.20.0/24 | 10.10.20.1 | HMIS |
| 30 | 10.10.30.0/24 | 10.10.30.1 | IT Management |
| 40 | 10.10.40.0/24 | 10.10.40.1 | CCTV |
| 50 | 10.10.50.0/24 | 10.10.50.1 | e-Khidmat |
| 60 | 10.10.60.0/24 | 10.10.60.1 | Servers |
| 70 | 10.10.70.0/24 | 10.10.70.1 | Printers/IoT |
| 80 | 10.10.80.0/24 | 10.10.80.1 | Guest |

## Branch Sites

| Site | Summary Network |
|---|---|
| e-Khidmat Branch | 10.20.0.0/16 |
| Remote Office | 10.30.0.0/16 |
| Education CCTV | 10.40.0.0/16 |

The ranges above are fictional private lab ranges.
