# Centralized Monitoring

## Recommended Platforms

- Zabbix
- LibreNMS
- PRTG Free/Trial for lab use

## Devices to Monitor

- Core switch
- Access switches
- Firewall
- VPN gateways
- Windows Server
- Linux monitoring server
- Demo PMIS/HMIS servers
- NVR
- CCTV test devices

## Suggested Metrics

- ICMP availability
- Interface utilization
- Packet loss
- Latency
- CPU usage
- Memory usage
- Disk usage
- VPN tunnel status
- Service availability
- Device uptime

## Alert Examples

- Device unreachable for 5 minutes
- VPN tunnel down
- Server CPU > 90%
- Disk utilization > 85%
- NVR unreachable
- Packet loss > 10%

Use fake hostnames and sanitized screenshots for GitHub.
