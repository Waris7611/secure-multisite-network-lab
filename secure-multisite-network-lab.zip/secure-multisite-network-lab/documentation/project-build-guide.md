# Step-by-Step Build Guide

## Phase 1 - Build the Core

1. Install EVE-NG or GNS3.
2. Add a core Layer-3 switch.
3. Add a firewall VM.
4. Create VLANs 10,20,30,40,50,60,70,80.
5. Configure SVI gateways.
6. Test inter-VLAN routing before firewall restrictions.

## Phase 2 - Add Servers

1. Create Windows Server VM.
2. Assign `10.10.60.10`.
3. Install AD DS, DNS, and DHCP.
4. Create lab domain `lab.local`.
5. Create PMIS/HMIS/e-Khidmat/IT OUs.
6. Join one or two Windows clients.

## Phase 3 - Firewall

1. Create internal VLAN/zone objects.
2. Create least-privilege firewall rules.
3. Block guest access to internal networks.
4. Restrict CCTV access.
5. Allow IT management only from VLAN 30.
6. Enable logging.

## Phase 4 - Branch VPN

1. Build an e-Khidmat branch subnet.
2. Add second firewall/router.
3. Configure IKEv2 IPsec.
4. Route only required networks.
5. Test connectivity and denied access.

## Phase 5 - CCTV Lab

1. Add NVR/test device IPs.
2. Put them in CCTV VLAN.
3. Add a test RTSP source if desired.
4. Monitor NVR/device reachability.

## Phase 6 - Monitoring

1. Deploy Zabbix or LibreNMS.
2. Add firewall, switch, server, and NVR.
3. Configure email/dashboard alerts in lab.
4. Simulate link/device outage.

## Phase 7 - Documentation

1. Take sanitized screenshots.
2. Add configs without secrets.
3. Add testing results.
4. Upload project to GitHub.
