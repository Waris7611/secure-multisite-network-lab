# Education CCTV Monitoring Lab

## Objective

Simulate a centralized CCTV monitoring network while keeping surveillance devices isolated from normal user traffic.

## Components

- CCTV VLAN: `10.10.40.0/24`
- Lab NVR: `10.10.40.10`
- Test Camera 01: `10.10.40.101`
- Test Camera 02: `10.10.40.102`
- Central Monitoring Server: `10.10.60.60`

## Recommended Controls

- Cameras/NVRs stay in dedicated VLAN.
- Allow only necessary traffic to monitoring systems.
- Block CCTV-to-user-VLAN access.
- Limit management access to IT-MGMT.
- Change default passwords in a real environment.
- Use HTTPS where supported.
- Monitor reachability and uptime.

## Portfolio Demo

Create screenshots showing:

1. CCTV VLAN interfaces.
2. NVR test IP reachable.
3. Camera/NVR status in monitoring dashboard.
4. Firewall rule blocking CCTV-to-user traffic.
5. Alert generated when a lab CCTV device is disconnected.

Do not upload live camera feeds, real RTSP URLs, production credentials, or identifiable surveillance footage.
