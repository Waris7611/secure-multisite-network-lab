# VLAN Design

## Why VLAN Segmentation?

VLANs reduce broadcast scope, improve manageability, and create security boundaries.

## VLAN Roles

### VLAN 10 - PMIS
For demo PMIS users. Access to PMIS application services only.

### VLAN 20 - HMIS
For demo HMIS users. Access to HMIS application services only.

### VLAN 30 - IT Management
For network administrators and management interfaces.

### VLAN 40 - CCTV
For cameras, NVRs, and CCTV-related devices. Restricted from normal user networks.

### VLAN 50 - e-Khidmat
For branch/service-center users.

### VLAN 60 - Servers
For Active Directory, DNS, monitoring, syslog, and application servers.

### VLAN 70 - Printers / IoT
For network printers and other limited-trust devices.

### VLAN 80 - Guest
Internet-only access. No access to internal subnets.
