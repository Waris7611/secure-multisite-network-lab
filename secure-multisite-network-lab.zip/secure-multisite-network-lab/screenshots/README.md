# Screenshots

Place sanitized project screenshots in this folder.

Recommended files:

```text
01-network-topology.png
02-vlan-interfaces.png
03-routing-table.png
04-firewall-rules.png
05-ipsec-vpn-status.png
06-active-directory.png
07-dhcp-dns.png
08-monitoring-dashboard.png
09-cctv-device-status.png
10-security-test.png
```

## Before Uploading

Blur or remove:

- Real public/private production IPs
- Usernames
- Passwords
- VPN PSKs
- Certificates
- Organization internal domains
- Camera URLs
- Real staff/patient/student data
- Live CCTV imagery
- Serial numbers if sensitive
